# Handoff: career-ops portal — Material Design 3 (dark, desktop)

## Overview
A full Material Design 3 reskin of the career-ops web portal (`web/` in
`SaadNiaziDev/career-ops-public`, branch `main`). Every route is designed: Today,
Add job, Explore, Pipeline (board + list + inbox triage), report detail, Apply,
Workers, Outreach, Portals, Analytics, CV editor, CV ingest, Config.

Scope decisions already made with the designer:
- **Dark scheme only.** Light is not designed yet.
- **Desktop only.** This is a web portal; no mobile or tablet layouts.
- **Full reimagining in the Material idiom**, not a skin over the current layout.
  Navigation moves from a 240px labelled sidebar to an MD3 navigation rail; the
  chevron "funnel" becomes primary tabs; elevation shadows become tonal surfaces.
- **Colour is generated from one seed**, the existing brand orange `#dd7627`, so
  the product stays recognisable while every surface, container and on-colour
  comes from MD3. A baseline-purple alternative is included for comparison.
- All copy in the designs is **verbatim from the current components** — do not
  rewrite it. Company names, scores, dates and contact rows are placeholder data.

## About the design files
The files in this bundle are **design references created in HTML** — prototypes
showing the intended look, not production code to copy. The task is to recreate
them in the existing Next.js 15 / React / Tailwind v4 codebase under `web/`,
using its established patterns.

Two of the files are "Design Components" (`.dc.html`): a streaming HTML format
used by the design tool. They open in a browser directly (`support.js` must sit
next to them). Read them as markup + inline styles; the data arrays that feed the
lists live in the `<script data-dc-script>` block at the bottom of each file.

## Fidelity
**High fidelity.** Exact hex values, type specs, corner radii, control heights and
copy are all final. Recreate pixel-for-pixel using MD3 tokens, not literals.

## How to implement — the intended order

1. **Tokens first.** Paste `m3-tokens.css` into `web/src/app/globals.css`, above
   the existing `@theme` block. Then map the existing semantic vars onto MD3
   roles so nothing breaks while you migrate:
   ```css
   @theme inline {
     --color-background: var(--md-sys-color-surface);
     --color-surface: var(--md-sys-color-surface-container);
     --color-surface-hover: var(--md-sys-color-surface-container-high);
     --color-border: var(--md-sys-color-outline-variant);
     --color-foreground: var(--md-sys-color-on-surface);
     --color-muted: var(--md-sys-color-on-surface-variant);
     --color-faint: var(--md-sys-color-outline);
     --color-brand: var(--md-sys-color-primary);
     --color-brand-foreground: var(--md-sys-color-on-primary);
     --color-brand-soft: var(--md-sys-color-secondary-container);
     --color-brand-text: var(--md-sys-color-primary);
   }
   ```
   `--brand-text` and the `hsl(26 80% 36%)` light-mode contrast workaround can be
   deleted — in a generated dark scheme `primary` already passes AA.

2. **Fonts.** Replace Inter + Instrument Serif in `web/src/lib/fonts.ts` with
   `Roboto_Flex` and `Roboto_Mono` from `next/font/google`, and add Material
   Symbols Outlined for icons (it replaces the lucide-react + `@ant-design/icons`
   mix). MD3's own guidance says Roboto/Roboto Flex is the correct default face;
   there is no editorial-serif role in MD3, so the Instrument Serif display style
   becomes Roboto Flex 700.

3. **Ant Design.** `web/src/lib/antd-theme.ts` already centralises antd tokens —
   point them at the MD3 roles (`colorPrimary: var(--md-sys-color-primary)`,
   `borderRadius: 12`, `borderRadiusLG: 28`, `Button.primaryShadow: "none"`).
   Where a component can't reach MD3 (the pipeline Table, Input.Search, Drawer),
   replace it with plain markup per section 9 of the kit. Do **not** introduce
   `@material/web` — it is in maintenance mode and has no Expressive support; MD3
   here means tokens + spec-aligned HTML/CSS.

4. **Shared chrome.** Build the navigation rail first (`Rail.dc.html` is the
   spec — 96px, 28dp trailing corner, 64×36 pill indicator, filled icon when
   active, labels always visible). It replaces `app-shell.tsx`'s `<aside>` and
   the antd `Menu`. `nav-items.ts` stays the source of truth for the item list.

5. **Screens**, in this order — each one reuses the last one's parts:
   Pipeline board → report detail → Today → Explore → the rest.

## Screens

All screens are 1280px wide in the mocks, laid out as
`display:flex` → rail (96px, `flex:none`) + content (`flex:1`, `padding:32px`).
Reading-column screens (Analytics, Add job, Config, Portals) cap content at
820–940px. Card grids use `display:grid` + `gap`, never margins.

### Pipeline — board (the primary screen)
Two variants are designed so you can compare, then one is chosen:
- **Classic MD3** (option `1b` in `Pipeline MD3.dc.html`), baseline purple seed:
  80px rail, 64px small top app bar, primary tabs with a count badge on the
  active tab, 6 equal columns of outlined cards (`corner-medium`, 1px
  `outline-variant`), monogram avatar 24px, score in an 8dp tonal badge.
- **Expressive** (option `1c`), brand seed — **this is the recommended one**:
  no app bar; the page title is `display-small-emphasized` (700 40/44) with the
  stat line under it; view switch is a connected tonal segmented control at 48dp;
  each stage is a `surface-container` block at `corner-extra-large` (28px)
  holding cards at `corner-large-increased` (20px) on `surface-container-high`;
  the Offer column is `primary-container` with its card in solid `primary`; the
  Interview column is `tertiary-container`. Column header is 13px/700 uppercase
  with `.1em` tracking and the count at 20px/700 on the right.

Stage semantics were remapped from the current emerald/sky dots to MD3 roles:
Evaluated → outline, Applied/Responded → secondary, Interview → tertiary,
Offer → primary, Closed → dimmed `surface-container-low`. **Confirm this with the
designer before shipping** — it is the most opinionated change in the set.

### Pipeline — inbox triage + list (`1d`)
72px list rows on a `surface-container` panel at 28dp, divider
`1px solid #2E2523`. Row: 22px checkbox, 40px monogram, 300px company/role stack,
150px location, ATS chip, 70px relative age (`Roboto Mono`), score pill,
40dp outlined "Save", 40dp text "Skip". Above it: the Quick add card, then the
facet chip row (8dp corner chips, single-select freshness group), then the free /
paid honesty line. The footer bar carries the token-cost message and the filled
"Score N selected" button — it must stay visible.

### Report detail (`1e`)
Breadcrumb → identity band (64px monogram at 20dp, company at 700 40/44, score at
700 64px in `primary`) → `grid-template-columns: minmax(0,1fr) 380px` with 28px
gap. Left: verdict card in `primary-container` at 28dp with the verdict at
500 20/30; then A and B expanded as `surface-container` sections with a 36px
`secondary-container` letter chip at 12dp; then C/D/E as collapsed 20dp rows with
a one-line teaser and `expand_more`; then the "Technical details · for
developers" divider. Right rail: Decision card (score, Apply / Below the line
pill in `tertiary-container`, 16px score meter with the 4.0 apply line marked at
80%, then fact rows divided by `outline-variant`), then "Act on it" with four
52dp full-width buttons.

### Today (`2a`)
Eyebrow → `Today's action queue` with a count badge → 3 hero buttons (56dp) →
4 stat cards → `grid-template-columns: minmax(0,1fr) 380px`. Left column:
Follow-ups due, Awaiting your decision (2-up decision cards), Fresh matches this
week (2-up discovery cards with a `tertiary-container` "Free scans · 0 tokens"
chip). Right: the compact Quick add card.

### Explore (`2b`)
The AI search box becomes a `surface-container` panel at 28dp with a
`primary-container` 1px border — the radial-halo effect is dropped; MD3 signals
focus with border colour, not a glow. Intent placeholder at 400 18/28 in
`outline`. Then example chips (40dp, `corner-full`), then a 3-up results grid of
24dp cards with ATS chip, relative age, an `unverified` chip in
`tertiary-container`, the AI "why" line in `primary`, and the two 44dp actions.

### Analytics (`2c`)
Max width 900px. 4 stat cards (offers card in `primary-container`), then three bar
sections. Bar row: 120px label, `flex:1` track 36px tall at `corner-medium` on
`surface-container`, fill in `secondary-container` (Offer row in `primary`), then
an 80px right-aligned value + share. Section headings are 12px/600 uppercase with
`.2em` tracking.

### Add job (`2d`), Portals (`2e`), Outreach (`2f`), CV editor (`2g`), Config (`2h`)
See the mocks; all reuse the parts above. Notable specifics:
- Portals: the broken-portals banner is `error-container`; status chips are
  tertiary (live), tertiary-container (live · empty), error-container (broken),
  surface-container-high (no ATS). Rows are 64px.
- Outreach: `grid-template-columns: 260px 220px 260px 120px 1fr`, 16px gap.
- CV editor: two 24dp panes, code pane `surface-container-low` with a 1px
  `outline-variant` border, preview `surface-container`.
- Config: three mode cards (selected = `secondary-container`, disabled = 55%
  opacity on `surface-container-low`), CLI rows at 64px/20dp, then the
  Company-logos switch (52×32, `primary` track, `on-primary` handle with a check).

### Apply (`3a`, `3b`)
Max width 880px. `3a` is the form-proxy with answers drafted: a 3-step phase rail
(filled pill = done, tonal pill = active, outlined = todo, 4px connector bars), a
`tertiary-container` "A few things to check" banner, the field list on a
`surface-container` panel where each field is a label + a 12dp box on
`surface-container-low`; fields needing confirmation get a `tertiary`
border and a "you confirm" chip. The resume field is a `tertiary-container` note.
Footer: filled "Fill the real form & review", outlined "Let the AI fill it", and
the never-submits guarantee with a `tertiary` shield icon.
`3b` is the agent-driving state: 88px `primary-container` orb, headline, a live
browser screenshot (placeholder in the mock — see Assets), then the numbered
drive-step list with 28px `secondary-container` turn badges.

### Workers (`3c`, `3d`)
History: 76px rows, status icon (`progress_activity` / `check_circle` /
`warning`), title + summary stack, score pill, status word.
Detail: `primary-container` hero at 28dp with the humanised current step and an
8px progress bar, then the step timeline (past steps transparent + 400 weight,
current step on `surface-container` + 600 weight), then the Output card.

### CV ingest (`3e`)
Review phase: title, "Ready to match" chip in `tertiary-container`, the local /
0-tokens chip, two 420px panes, then "Save & find my matches" (56dp filled),
"Start over" (text), and the "Saved locally to cv.md" lock note.

## Interactions & behaviour
The mocks are **static screens** — no animation was built. Implement behaviour
from the existing components (they are unchanged; only presentation moves), and
use MD3 motion tokens for every transition:

| Transition | Token | Duration |
|---|---|---|
| Stage/tab change, view switch (board ↔ table) | emphasized `cubic-bezier(.2,0,0,1)` | 500ms |
| Cards, panels, sheets entering | emphasized-decelerate `cubic-bezier(.05,.7,.1,1)` | 400ms |
| Elements leaving | emphasized-accelerate `cubic-bezier(.3,0,.8,.15)` | 200ms |
| Hover, selection, colour fades | standard `cubic-bezier(.2,0,0,1)` | 300ms |

Spring physics is Compose-only — do not try to emulate it on web.

**Hover states** replace the current shadows: a card at `surface-container` goes
to `surface-container-high`; an outlined button tints its background with
`primary` at 8%. Focus-visible is a 2px `primary` outline at 2px offset, never a
removed outline. Respect `prefers-reduced-motion` as the current CSS already does.

Loading, error and empty states are **not designed yet** (first-run home, the
pipeline empty panel, Explore's discovering state). Keep the existing ones and
restyle them with tokens until they are designed.

## State management
Unchanged. Every screen maps 1:1 onto an existing component, so the existing
providers (`JobsProvider`, `PipelineProvider`, `ApplyProvider`, `ExploreProvider`)
and URL-param state in `pipeline-view.tsx` (`tab`, `view`, `min`, `sort`, `dir`,
`q`) stay exactly as they are. This is a presentation change.

## Design tokens
`m3-tokens.css` in this bundle is authoritative. Summary:

**Colour (dark, seed #dd7627)** — primary `#FFB68F` / on `#4E2600`; primary-container
`#6E3900` / on `#FFDBC8`; secondary-container `#5A4130` / on `#FFDCC5`; tertiary
`#CBCB94`; tertiary-container `#484A00` / on `#E7E7AE`; error `#FFB4AB`;
error-container `#93000A` / on `#FFDAD6`; surface `#191211`; on-surface `#F0DFD8`;
on-surface-variant `#D8C2B9`; container-lowest `#130C0B`, low `#1F1817`,
container `#221A18`, high `#312825`, highest `#3D3330`; outline `#A08D85`;
outline-variant `#53433E`.

**Type** (Roboto Flex; Roboto Mono for eyebrows, dates, code) — display-small
400 36/44, display-small-emphasized 700 40/44, headline-medium 400 28/36,
title-large 400 22/28, title-medium 500 16/24, title-small 500 14/20, body-large
400 16/24, body-medium 400 14/20, body-small 400 12/16, label-large 500 14/20,
label-medium 500 12/16, label-small 500 11/16.

**Shape** — 8 chips, 12 field boxes/bars, 16 text fields/FAB, 20 nested cards,
28 page panels, full for buttons/badges/switches.

**Spacing** — 4 / 8 / 12 / 16 / 24 / 32. Page padding 32, section gap 20, card
padding 22–26, list-row gap 10.

**Control heights** — 56 hero button, 52 rail action, 48 segmented, 44 inline,
40 row action; 48 icon-only hit target; list rows 64–76.

**Elevation** — none. No `box-shadow` anywhere; depth is a tonal step.

## Assets
- **Icons**: Material Symbols Outlined (Google Fonts), replacing lucide-react and
  `@ant-design/icons`. Names used are in the markup, e.g. `dashboard`, `link`,
  `explore`, `checklist`, `group`, `radar`, `bar_chart`, `description`,
  `settings`, `bolt`, `inbox`, `open_in_new`, `expand_more`, `check_circle`,
  `warning`, `ads_click`, `auto_awesome`, `progress_activity`.
- **Company logos**: unchanged — the existing `/api/logo` favicon proxy with a
  monogram fallback. Mocks show the monogram (rounded square, `secondary-container`).
- **Browser screenshot in Apply `3b`**: a labelled striped placeholder. The
  designer cannot generate images; use the real Playwright thumbnail the existing
  `DrivePanel` already receives.

## Files in this bundle
| File | What it is |
|---|---|
| `Pipeline MD3.dc.html` | All 19 screens, newest turn first: turn 3 = Apply / Workers / CV ingest, turn 2 = Today / Explore / Analytics / Add job / Portals / Outreach / CV / Config, turn 1 = the audit, the two Pipeline boards, inbox+list, report detail, dynamic-colour seeds |
| `Material 3 Kit.dc.html` | The component kit: colour roles, type scale, shape and tonal ladders, button/chip/input/container/nav specimens, motion, spacing, the old-component → MD3 mapping table, and the implementation rules |
| `Rail.dc.html` | The navigation rail spec, driven by an `active` prop |
| `m3-tokens.css` | The `--md-sys-*` custom properties — paste into `globals.css` |
| `support.js` | Runtime needed to open the `.dc.html` files in a browser |

Open `Material 3 Kit.dc.html` first, then `Pipeline MD3.dc.html`.

## Rules (from the kit — repeated because they are the whole point)
1. No hex values in components. Every colour is `var(--md-sys-color-*)`.
2. No raw `border-radius`. Shape tokens only; buttons and chips are `corner-full`.
3. No shadows. Depth is a tonal step up the surface-container stack.
4. Only pair `X` with `on-X`.
5. Never mix `@material/mdc-*` (MD2) with MD3. Ant Design gets token overrides or
   replacement, not both.
6. Interactive targets 40dp minimum, 48dp for icon-only.
7. Desktop-only portal: navigation rail at all widths, reading columns capped.

## Open questions for the designer
1. Stage colours remapped to MD3 roles (tertiary for Interview, primary for
   Offer) instead of the current emerald/sky — confirm?
2. The Workers tray and usage meter lived in the old sidebar. The rail is
   icon-only, so they were moved to `/jobs`. Confirm, or design a rail badge.
3. Light scheme, empty/first-run states, and the small in-place controls (status
   select, delete confirm, score-methodology popover) are not designed yet.
